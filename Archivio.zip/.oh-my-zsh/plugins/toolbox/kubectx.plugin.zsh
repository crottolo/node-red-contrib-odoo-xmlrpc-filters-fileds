function toolbox_prompt_info() {
  [[ -f /run/.toolboxenv ]] && echo "⬢"
}
