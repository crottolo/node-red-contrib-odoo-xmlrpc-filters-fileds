#!/usr/bin/env zsh
# vim:ft=zsh ts=2 sw=2 sts=2

_emotty_sets[floral]="
  hibiscus
  cherry_blossom
  blossom
  sunflower
  bouquet
  tulip
  rose
  four_leaf_clover
  seedling
  herb
  palm_tree
  evergreen_tree
  deciduous_tree
  "
